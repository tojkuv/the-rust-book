use add_one_8732;

fn main() {
    let num = 10;
    println!("Hello, world! {num} plus one is {}!", add_one_8732::add_one(num));
}